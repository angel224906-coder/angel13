const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Book = require('../models/book');

// POST /api/books -> add a new book
router.post('/', async (req, res, next) => {
  try {
    const book = new Book(req.body);
    const saved = await book.save();
    return res.status(201).json({ success: true, data: saved });
  } catch (err) {
    // Mongoose validation error
    if (err.name === 'ValidationError') {
      return res.status(400).json({ success: false, error: err.message });
    }
    next(err);
  }
});

// GET /api/books -> get all books
router.get('/', async (req, res, next) => {
  try {
    const books = await Book.find().sort({ createdAt: -1 });
    return res.status(200).json({ success: true, data: books });
  } catch (err) {
    next(err);
  }
});

// PUT /api/books/:id -> update a book
router.put('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, error: 'Invalid book id' });
    }

    const updated = await Book.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true
    });

    if (!updated) {
      return res.status(404).json({ success: false, error: 'Book not found' });
    }

    return res.status(200).json({ success: true, data: updated });
  } catch (err) {
    if (err.name === 'ValidationError') {
      return res.status(400).json({ success: false, error: err.message });
    }
    next(err);
  }
});

// DELETE /api/books/:id -> delete a book
router.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, error: 'Invalid book id' });
    }

    const removed = await Book.findByIdAndDelete(id);
    if (!removed) {
      return res.status(404).json({ success: false, error: 'Book not found' });
    }

    return res.status(200).json({ success: true, data: removed, message: 'Book deleted' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
